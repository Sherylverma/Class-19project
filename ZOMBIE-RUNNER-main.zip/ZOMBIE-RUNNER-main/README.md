# ABOUT THIS PROJECT

This is a endless runner game where you are a little cute princess and you need to run away from a zombie. Also you need to stay away from the obstacles. If you hit a obstacle, you will fall and the zombie will kill you. This was created in Javascript in P5.js by me getting taught from WhitehatJR. This is also a project of the Capstone Class of Class 19(YOUR OWN INFINITE RUNNER GAME) in WhitehatJR Pro Course. To edit the game change the code in the sketch.js file.

# ABOUT ME

![My Image](swastik.png)

- 👋 Hi, I’m [Swastik Bhattacharjee](https://github.com/Swastik-WhitehatJR).
- 👀 I’m interested in Programming and designing.
- 🌱 I’m currently learning Web Development.
- 💞️ I’m now learning to it on WhitehatJR.
- 📫 You can reach me by mentioning me in github at @Swastik-WhitehatJR.
- 💌 You can to mail me in swastikbhattacharjee.07@gmail.com (my email id).
